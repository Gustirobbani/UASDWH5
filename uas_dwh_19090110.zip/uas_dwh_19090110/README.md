# analytic-hierarchy-process
Simple decision support system application with AHP method.

## Installation
- create new database in MySQL server (phpMyAdmin)
- edit file config.php
- import database/database.sql into your new database
- run your website

## Screenshot

<img src="screenshot/1.png" alt="halaman kriteria" style="width: 250px;"/>

<img src="screenshot/2.png" alt="matriks nilai kriteria" style="width: 250px;"/>

<img src="screenshot/3.png" alt="hasil perhitungan" style="width: 250px;"/>